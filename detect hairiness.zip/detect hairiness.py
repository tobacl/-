import cv2
import numpy as np

#1.1 中值滤波3x3kernel
img = cv2.imread("D:/cv/detect hairiness/img/1/1.jpg")
filtered_img = cv2.medianBlur(img, 3)

#1.2 纱线灰度图像转换成二值图像
img_gray = cv2.cvtColor(filtered_img, cv2.COLOR_BGR2GRAY)
threshold_value, threshold_image = cv2.threshold(img_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
max_value = 255 # 二值图像的最大值
ret, img_binary = cv2.threshold(img_gray, threshold_value, max_value, cv2.THRESH_BINARY)

#2.1 开运算，先腐蚀后膨胀（r=3）
# 定义一个椭圆形的结构元素，用于开运算
kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
opened_img = cv2.morphologyEx(img_binary, cv2.MORPH_OPEN, kernel)

#2.2 对纱线条干进行膨胀（r=6）
kernel1 = np.ones((6,6), np.uint8)
dilated_img = cv2.dilate(img_gray, kernel1, iterations=1)
#2.3大津阈值法

window_size = 12
variance_threshold = 5

# 将图像按照窗口大小分块处理
rows, cols = opened_img.shape
row_blocks = rows // window_size
col_blocks = cols // window_size

# 初始化矩阵Z
Z = np.zeros((rows, cols), dtype=np.uint8)

# 对于每个小窗口进行处理
for i in range(row_blocks):
    for j in range(col_blocks):
        # 获取当前窗口的位置和像素值
        row_start = i * window_size
        row_end = row_start + window_size
        col_start = j * window_size
        col_end = col_start + window_size
        window = opened_img[row_start:row_end, col_start:col_end]
        window_2 =dilated_img[row_start:row_end, col_start:col_end]

        # 检查窗口是否全部为1
        if np.all(window == 1):
            # 是条干区域，将所有像素值设为0
            Z[row_start:row_end, col_start:col_end] = 0
        else:
            # 是非条干区域，计算像素值方差
            variance = np.var(window_2[window_2 != 0])
            if variance > variance_threshold:
                # 方差大于阈值，采用大津阈值法分割
                _, threshold = cv2.threshold(window_2, threshold_value, max_value, cv2.THRESH_BINARY+ cv2.THRESH_OTSU)
                Z[row_start:row_end, col_start:col_end] = threshold
            else:
                # 方差小于阈值，将所有像素值设为0
                Z[row_start:row_end, col_start:col_end] = 0

# cv2.imshow("result", Z)
# cv2.waitKey(0)
# cv2.destroyAllWindows()

cv2.imwrite('./saveimg/1.jpg', img_gray)
cv2.imwrite('./saveimg/2.jpg', img_binary)
cv2.imwrite('./saveimg/3.jpg', opened_img)
cv2.imwrite('./saveimg/4.jpg', dilated_img)
cv2.imwrite('./saveimg/5.jpg', Z)

# Z=cv2.subtract(opened_img,dilated_img)
