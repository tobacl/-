import cv2

def count_edge_pixels(image_path):
    # 读取毛羽照片
    img = cv2.imread(image_path)

    # 将图像转换为灰度图像
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    threshold_value, threshold_image = cv2.threshold(img_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    max_value = 255  # 二值图像的最大值
    ret, img_binary = cv2.threshold(img_gray, threshold_value, max_value, cv2.THRESH_BINARY)

    # 2.1 开运算，先腐蚀后膨胀（r=3）
    # 定义一个椭圆形的结构元素，用于开运算
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    opened_img = cv2.morphologyEx(img_binary, cv2.MORPH_OPEN, kernel)


    # 用Canny算法检测边缘
    edges = cv2.Canny(opened_img, 200, 250)

    cv2.imshow("Image", edges)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # 统计边缘像素点数量
    count = cv2.countNonZero(edges)

    # return count
    print(count)
if __name__ == '__main__':
    img_path ='D:/cv/detect hairiness/img/1/8.jpg'
    count_edge_pixels(img_path)
