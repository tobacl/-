import cv2
import numpy as np

#1.1 中值滤波3x3kernel
img = cv2.imread("D:/cv/detect hairiness/img/1/5.jpg")
filtered_img = cv2.medianBlur(img, 3)

#1.2 纱线灰度图像转换成二值图像
img_gray = cv2.cvtColor(filtered_img, cv2.COLOR_BGR2GRAY)
threshold_value, threshold_image = cv2.threshold(img_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
max_value = 255 # 二值图像的最大值
ret, img_binary = cv2.threshold(img_gray, threshold_value, max_value, cv2.THRESH_BINARY)

#2.1 开运算，先腐蚀后膨胀（r=3）
# 定义一个椭圆形的结构元素，用于开运算
kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
opened_img = cv2.morphologyEx(img_binary, cv2.MORPH_OPEN, kernel)

#2.2 对纱线条干进行膨胀（r=6）
kernel1 = np.ones((6,6), np.uint8)
dilated_img = cv2.dilate(img_gray, kernel1, iterations=1)
#2.3大津阈值法
threshold_value, dilated_img0= cv2.threshold(img_gray, 127, 255, cv2.THRESH_TRUNC)  #灰度图直接上
threshold_value, dilated_img1= cv2.threshold(dilated_img, 127, 255, cv2.THRESH_TRUNC)  #膨胀过后的图

img11=cv2.subtract(dilated_img1,opened_img)
img00=cv2.subtract(dilated_img0,opened_img)   #就是这个最好了

#背景变黑
threshold = 60
for i in range(img00.shape[0]):
    for j in range(img00.shape[1]):
        if img00[i][j] < threshold:
            img00[i][j] = 0


#
# cv2.imwrite('./saveimg/7/1.jpg', img_gray)
# cv2.imwrite('./saveimg/7/2.jpg', img_binary)
# cv2.imwrite('./saveimg/7/3.jpg', opened_img)
# cv2.imwrite('./saveimg/7/4.jpg', dilated_img)
# cv2.imwrite('./saveimg/7/5.jpg', dilated_img0)
# cv2.imwrite('./saveimg/7/6.jpg', img00)
# cv2.imwrite('./saveimg/7/7.jpg', dilated_img1)
# cv2.imwrite('./saveimg/7/8.jpg', img11)


count = cv2.countNonZero(img00)
print(count)


# cv2.imshow("result", Z)
# cv2.waitKey(0)
# cv2.destroyAllWindows()

